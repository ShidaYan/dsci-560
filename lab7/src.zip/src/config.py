THINGSBOARD_HOST = "http://localhost:8080"
TENANT_EMAIL = "tenant@thingsboard.org"
TENANT_PASSWORD = "tenant"
DEVICES = {
    "MyPhone": "BrNyCWj3PiIfmry8uN2U",
    "Phone2": "V76qjxK4LNpd1jnpuiXz",
    "Phone3": "dtA7UZeDZMSF3w3vXC63",
}
TELEMETRY_URL = THINGSBOARD_HOST + "/api/v1/{token}/telemetry"
