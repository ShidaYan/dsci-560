import json, os, folium
from folium import plugins

COLORS = {"MyPhone":"red","Phone2":"blue","Phone3":"green"}

with open("telemetry_data.json") as f:
    data = json.load(f)

all_lats = [p["lat"] for pts in data.values() for p in pts]
all_lons = [p["lon"] for pts in data.values() for p in pts]
m = folium.Map(location=[sum(all_lats)/len(all_lats), sum(all_lons)/len(all_lons)], zoom_start=15)

for name, points in data.items():
    color = COLORS.get(name, "purple")
    if len(points) > 1:
        folium.PolyLine([(p["lat"],p["lon"]) for p in points], color=color, weight=3, tooltip=f"{name} trail").add_to(m)
    if points:
        latest = points[-1]
        folium.Marker([latest["lat"],latest["lon"]], tooltip=f"{name}",
            popup=f"{name}<br>Lat:{latest['lat']}<br>Lon:{latest['lon']}<br>Time:{latest['time']}",
            icon=folium.Icon(color=color)).add_to(m)

plugins.Fullscreen().add_to(m)
os.makedirs("output", exist_ok=True)
m.save("output/tracker_map.html")
print("[OK] Map saved to output/tracker_map.html")
