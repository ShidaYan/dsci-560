import requests
from config import DEVICES, TELEMETRY_URL

locations = {
    "MyPhone": (34.0195, -118.2863),
    "Phone2": (34.0689, -118.2605),
    "Phone3": (34.0224, -118.2851),
}

for name, token in DEVICES.items():
    lat, lon = locations[name]
    url = TELEMETRY_URL.format(token=token)
    r = requests.post(url, json={"lat": lat, "lon": lon}, headers={"Content-Type": "application/json"})
    status = "OK" if r.status_code == 200 else f"FAIL({r.status_code})"
    print(f"[{status}] {name}: lat={lat}, lon={lon}")
