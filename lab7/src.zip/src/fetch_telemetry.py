import requests, json, time
from datetime import datetime
from config import THINGSBOARD_HOST, TENANT_EMAIL, TENANT_PASSWORD

r = requests.post(f"{THINGSBOARD_HOST}/api/auth/login", json={"username":TENANT_EMAIL,"password":TENANT_PASSWORD})
token = r.json()["token"]
headers = {"X-Authorization": f"Bearer {token}"}
print("[OK] Logged in")

r = requests.get(f"{THINGSBOARD_HOST}/api/tenant/devices", headers=headers, params={"pageSize":100,"page":0})
devices = [d for d in r.json()["data"] if d["name"] in ("MyPhone","Phone2","Phone3")]

all_data = {}
end_ts = int(time.time()*1000)
start_ts = end_ts - 86400000

for d in devices:
    name, did = d["name"], d["id"]["id"]
    r = requests.get(f"{THINGSBOARD_HOST}/api/plugins/telemetry/DEVICE/{did}/values/timeseries",
        headers=headers, params={"keys":"lat,lon","startTs":start_ts,"endTs":end_ts,"limit":100})
    data = r.json()
    points = []
    lon_map = {x["ts"]:float(x["value"]) for x in data.get("lon",[])}
    for x in data.get("lat",[]):
        if x["ts"] in lon_map:
            points.append({"time":datetime.fromtimestamp(x["ts"]/1000).strftime("%Y-%m-%d %H:%M:%S"),
                "timestamp":x["ts"],"lat":float(x["value"]),"lon":lon_map[x["ts"]]})
    points.sort(key=lambda x:x["timestamp"])
    all_data[name] = points
    print(f"[{name}] {len(points)} points")

with open("telemetry_data.json","w") as f:
    json.dump(all_data, f, indent=2)
print(f"\nSaved to telemetry_data.json")
