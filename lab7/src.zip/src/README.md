# DSCI 560 - Lab Assignment 7
## Mobile Phone-based IoT Network with IoT Hub in Cloud

### Team Members
- Shida Yan
- Tianqi Qiu
- Herun Kan

### Project Overview
This project implements a **real-time multi-device phone tracking system** using mobile phones as IoT devices. We use the OwnTracks app to stream GPS telemetry data from multiple phones to a ThingsBoard IoT hub deployed on AWS EC2, and visualize the data on interactive maps.

### Architecture
```
┌─────────────┐     HTTP POST      ┌──────────────────────┐
│  Phone 1    │ ──────────────────> │                      │
│ (OwnTracks) │                     │   ThingsBoard CE     │
├─────────────┤     HTTP POST      │   (AWS EC2)          │
│  Phone 2    │ ──────────────────> │                      │
│ (OwnTracks) │                     │   PostgreSQL DB      │
├─────────────┤     HTTP POST      │   Port 8080          │
│  Phone 3    │ ──────────────────> │                      │
│ (OwnTracks) │                     └──────────┬───────────┘
└─────────────┘                                │
                                               │ REST API
                                               ▼
                                    ┌──────────────────────┐
                                    │  Python Scripts       │
                                    │  - send_telemetry.py  │
                                    │  - fetch_telemetry.py │
                                    │  - visualize_map.py   │
                                    │  - simulate_routes.py │
                                    └──────────────────────┘
```

### Tech Stack
- **IoT Platform**: ThingsBoard Community Edition v3.8.1
- **Cloud**: AWS EC2 (Ubuntu 24.04 LTS, t2.medium)
- **Database**: PostgreSQL 16
- **Mobile App**: OwnTracks (iOS / Android)
- **Protocol**: HTTP (REST API)
- **Programming Language**: Python 3
- **Visualization**: Folium (OpenStreetMap), ThingsBoard Dashboard

### Project Structure
```
iot-phone-tracker/
├── README.md                 # Project documentation
├── requirements.txt          # Python dependencies
├── config.py                 # Server and device configuration
├── send_telemetry.py         # Send GPS data to ThingsBoard
├── fetch_telemetry.py        # Fetch telemetry data via REST API
├── visualize_map.py          # Generate interactive map with device tracks
├── simulate_routes.py        # Simulate multiple devices moving on routes
└── output/                   # Generated map files (HTML)
```

### Setup Instructions

#### 1. Prerequisites
- Python 3.8+
- AWS EC2 instance with ThingsBoard installed
- OwnTracks app installed on mobile phones

#### 2. Install Python Dependencies
```bash
pip install -r requirements.txt
```

#### 3. Configure
Edit `config.py` with your ThingsBoard server IP and device tokens:
```python
THINGSBOARD_HOST = "http://YOUR_EC2_IP:8080"
DEVICES = {
    "MyPhone": "YOUR_TOKEN_1",
    "Phone2": "YOUR_TOKEN_2",
    "Phone3": "YOUR_TOKEN_3",
}
```

#### 4. Run Scripts

**Send test telemetry data:**
```bash
python send_telemetry.py
```

**Simulate multiple devices moving on routes:**
```bash
python simulate_routes.py
```

**Fetch telemetry history from ThingsBoard:**
```bash
python fetch_telemetry.py
```

**Generate interactive map visualization:**
```bash
python visualize_map.py
```

### Design Decisions
1. **HTTP Protocol**: Chosen for simplicity and compatibility with OwnTracks. MQTT could offer lower latency but HTTP is easier to debug and configure.
2. **PostgreSQL**: Used for structured telemetry storage with time-based partitioning (monthly) for efficient queries.
3. **AWS EC2**: Provides full control over the IoT hub infrastructure and allows custom security group configurations.
4. **OpenStreetMap + Folium**: Free, open-source mapping solution that generates interactive HTML maps without API keys.
5. **Multi-device Architecture**: Each phone is registered as a separate device in ThingsBoard with unique access tokens, enabling independent tracking and visualization.

### Custom Mapping Solution
Our custom mapping solution tracks multiple team members in real-time and generates interactive visualizations:
- **Real-time tracking**: All three phones send GPS data simultaneously
- **Route simulation**: Python script simulates realistic walking/driving routes for demonstration
- **Interactive maps**: Generated HTML maps show device positions, movement trails, and metadata
- **Dashboard**: ThingsBoard dashboard displays all devices on a single OpenStreetMap widget

### Screenshots
(Add screenshots of your ThingsBoard dashboard and generated maps here)

### Video Demo
(Add link to your demo video here)
