import requests, time, random
from config import DEVICES, TELEMETRY_URL

def interpolate(waypoints, steps):
    route = []
    for i in range(len(waypoints)-1):
        for j in range(steps // (len(waypoints)-1)):
            t = j / (steps // (len(waypoints)-1))
            lat = waypoints[i][0] + t*(waypoints[i+1][0]-waypoints[i][0]) + random.uniform(-0.0001,0.0001)
            lon = waypoints[i][1] + t*(waypoints[i+1][1]-waypoints[i][1]) + random.uniform(-0.0001,0.0001)
            route.append((lat, lon))
    return route

routes = {
    "MyPhone": interpolate([(34.0224,-118.2851),(34.0205,-118.2855),(34.0195,-118.2863),(34.0189,-118.2840),(34.0210,-118.2820)], 30),
    "Phone2": interpolate([(34.0184,-118.2920),(34.0186,-118.2880),(34.0190,-118.2850),(34.0196,-118.2770)], 30),
    "Phone3": interpolate([(34.0163,-118.2878),(34.0155,-118.2870),(34.0148,-118.2855),(34.0175,-118.2850)], 30),
}

print("Simulating 3 devices moving... (30 seconds)")
for step in range(30):
    print(f"\n--- Step {step+1}/30 ---")
    for name, token in DEVICES.items():
        idx = min(step, len(routes[name])-1)
        lat, lon = routes[name][idx]
        url = TELEMETRY_URL.format(token=token)
        requests.post(url, json={"lat":round(lat,6),"lon":round(lon,6)}, headers={"Content-Type":"application/json"})
        print(f"  [{name}] ({lat:.6f}, {lon:.6f})")
    time.sleep(1)
print("\nDone! Check ThingsBoard dashboard.")
