# The Coach — Health & Fitness

UI prototype for the group fitness chatbot.

## Setup

```bash
npm install
npm run dev
```

Open http://localhost:5173
