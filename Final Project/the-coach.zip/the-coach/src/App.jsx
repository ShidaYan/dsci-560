import { useState, useRef, useEffect, useCallback } from "react";

/* ========== CONFIG ========== */

const API_KEY = "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"; 
const BASE_URL = "https://api.openai.com/v1";
const MODEL = "gpt-4o";

const SYSTEM_PROMPT = `You are Coach Fit, an AI fitness coach in a group chat called "The Coach".
You help fitness beginners of all ages (18-25, 30-45, 50+) with personalized workout plans,
running advice, injury prevention, nutrition guidance, and form checks when users share photos.

Rules:
- Keep responses concise (2-4 sentences max)
- Use 1 relevant emoji per message
- If a user shares a photo, analyze it and give specific form or equipment feedback
- Be warm, encouraging, and accessible — never intimidating
- Always recommend consulting a doctor for any pain or injury`;

/* ========== CONSTANTS ========== */

const O = "#FC4C02";

const ppl = [
  { id: "coach", name: "Coach Fit", pic: "🏋️", tag: "AI Coach", status: "online" },
  { id: "user", name: "You", pic: "👤", tag: "Member", status: "online" },
  { id: "sarah", name: "Sarah M.", pic: "🧘", tag: "Member", status: "online" },
  { id: "mike", name: "Mike R.", pic: "🏃", tag: "Member", status: "away" },
  { id: "jenny", name: "Jenny L.", pic: "🏊", tag: "Member", status: "offline" },
];

function who(id) { return ppl.find(p => p.id === id) || ppl[1]; }

function timeNow() {
  let d = new Date(), h = d.getHours(), m = d.getMinutes();
  return `${h % 12 || 12}:${m < 10 ? "0" + m : m} ${h >= 12 ? "PM" : "AM"}`;
}

/* ========== SHARED COMPONENTS ========== */

function Dot({ s }) {
  let c = s === "online" ? "#34A853" : s === "away" ? "#FBBC04" : "#ccc";
  return <div style={{ width: 8, height: 8, borderRadius: 4, background: c, border: "2px solid #fff", position: "absolute", bottom: -1, right: -1 }} />;
}

function Avatar({ id, size = 32 }) {
  let p = who(id);
  let isCoach = id === "coach";
  return (
    <div style={{ position: "relative", flexShrink: 0 }}>
      <div style={{
        width: size, height: size, borderRadius: size / 2, fontSize: size * 0.45,
        background: isCoach ? O : "#F0F0F0",
        color: isCoach ? "#fff" : "#333",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>{p.pic}</div>
      {size >= 30 && <Dot s={p.status} />}
    </div>
  );
}

function Header({ title, subtitle, right }) {
  return (
    <div style={{
      height: 56, padding: "0 14px", display: "flex", alignItems: "center", gap: 10,
      background: "#fff", borderBottom: "1px solid #EDEDED", flexShrink: 0,
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 18, background: O,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 17, color: "#fff", flexShrink: 0,
      }}>🏋️</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 700, fontSize: 15, color: "#1A1A1A", letterSpacing: -0.2 }}>{title}</div>
        {subtitle && <div style={{ fontSize: 11, color: "#888", marginTop: 1 }}>{subtitle}</div>}
      </div>
      {right}
    </div>
  );
}

function TabBar({ tab, setTab }) {
  const tabs = [
    { key: "feed", icon: "🏠", label: "Feed" },
    { key: "chat", icon: "💬", label: "Chat" },
    { key: "sessions", icon: "📅", label: "Sessions" },
    { key: "plan", icon: "📋", label: "Plan" },
    { key: "profile", icon: "👤", label: "Profile" },
  ];
  return (
    <div style={{
      height: 52, display: "flex", borderTop: "1px solid #EDEDED",
      background: "#fff", flexShrink: 0,
    }}>
      {tabs.map(t => (
        <button key={t.key} onClick={() => setTab(t.key)} style={{
          flex: 1, background: "none", border: "none", cursor: "pointer",
          display: "flex", flexDirection: "column", alignItems: "center",
          justifyContent: "center", gap: 2, padding: 0,
        }}>
          <span style={{ fontSize: 18, opacity: tab === t.key ? 1 : 0.3, transition: "opacity .15s" }}>{t.icon}</span>
          <span style={{ fontSize: 10, fontWeight: 600, color: tab === t.key ? O : "#aaa", transition: "color .15s" }}>{t.label}</span>
        </button>
      ))}
    </div>
  );
}

/* ========== FEED ========== */

const feedData = [
  {
    user: "mike", type: "Run", title: "Morning Run", time: "Today at 7:32 AM",
    stats: [{ l: "Distance", v: "5.2 km" }, { l: "Time", v: "28:14" }, { l: "Pace", v: "5'26\"/km" }],
    img: "https://images.unsplash.com/photo-1571008887538-b36bb32f4571?w=500&h=200&fit=crop",
    likes: 8, comments: 3,
  },
  {
    user: "sarah", type: "Walk", title: "Evening Walk — Day 7! 🎉", time: "Yesterday at 6:15 PM",
    stats: [{ l: "Distance", v: "1.8 km" }, { l: "Time", v: "22:30" }, { l: "Steps", v: "2,840" }],
    img: null, likes: 12, comments: 5,
  },
  {
    user: "jenny", type: "Swim", title: "Pool Session", time: "Yesterday at 10:00 AM",
    stats: [{ l: "Distance", v: "800 m" }, { l: "Time", v: "25:00" }, { l: "Laps", v: "16" }],
    img: "https://images.unsplash.com/photo-1530549387789-4c1017266635?w=500&h=200&fit=crop",
    likes: 6, comments: 2,
  },
  {
    user: "mike", type: "Strength", title: "Upper Body Day", time: "2 days ago",
    stats: [{ l: "Duration", v: "45 min" }, { l: "Exercises", v: "6" }, { l: "Sets", v: "18" }],
    img: null, likes: 5, comments: 1,
  },
  {
    user: "user", type: "Walk", title: "First Walk!", time: "3 days ago",
    stats: [{ l: "Distance", v: "1.2 km" }, { l: "Time", v: "16:40" }, { l: "Steps", v: "1,920" }],
    img: null, likes: 15, comments: 7,
  },
];

function Feed() {
  const [liked, setLiked] = useState({});
  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F5F5F5" }}>
      {feedData.map((item, i) => {
        let p = who(item.user);
        let heart = liked[i];
        return (
          <div key={i} style={{ background: "#fff", marginBottom: 8 }}>
            <div style={{ padding: "12px 14px 8px", display: "flex", alignItems: "center", gap: 10 }}>
              <Avatar id={item.user} size={36} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A" }}>{p.name}</div>
                <div style={{ fontSize: 11, color: "#999" }}>{item.time}</div>
              </div>
              <span style={{ fontSize: 11, color: O, fontWeight: 600, background: `${O}0D`, padding: "3px 10px", borderRadius: 10 }}>{item.type}</span>
            </div>

            <div style={{ padding: "0 14px 8px", fontWeight: 600, fontSize: 15, color: "#1A1A1A" }}>{item.title}</div>

            {item.img && <img src={item.img} alt="" style={{ width: "100%", height: 160, objectFit: "cover", display: "block" }} />}

            <div style={{ display: "flex", padding: "12px 14px" }}>
              {item.stats.map((s, j) => (
                <div key={j} style={{
                  flex: 1, textAlign: "center",
                  borderRight: j < item.stats.length - 1 ? "1px solid #F0F0F0" : "none",
                }}>
                  <div style={{ fontSize: 16, fontWeight: 700, color: "#1A1A1A" }}>{s.v}</div>
                  <div style={{ fontSize: 10, color: "#999", marginTop: 2, textTransform: "uppercase", letterSpacing: 0.4 }}>{s.l}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", padding: "8px 14px 12px", gap: 20, borderTop: "1px solid #F5F5F5" }}>
              <button onClick={() => setLiked(prev => ({ ...prev, [i]: !prev[i] }))} style={{
                background: "none", border: "none", cursor: "pointer",
                fontSize: 13, color: heart ? O : "#888", fontWeight: 500,
                display: "flex", alignItems: "center", gap: 5, padding: 0,
              }}>{heart ? "🧡" : "🤍"} {item.likes + (heart ? 1 : 0)}</button>
              <span style={{ fontSize: 13, color: "#888", display: "flex", alignItems: "center", gap: 5 }}>💬 {item.comments}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ========== PLAN ========== */

const weekPlan = [
  { day: "Mon", label: "Upper Body", done: true, items: ["Push-ups 3×10", "Dumbbell rows 3×12", "Shoulder press 3×10", "Plank 3×30s"] },
  { day: "Tue", label: "Cardio Walk", done: true, items: ["Brisk walk 20 min", "Cool-down stretch 5 min"] },
  { day: "Wed", label: "Lower Body", done: true, items: ["Squats 3×15", "Lunges 3×10 each", "Calf raises 3×20", "Wall sit 3×20s"] },
  { day: "Thu", label: "Rest Day", done: false, items: ["Light stretching", "Foam rolling (optional)"], today: true },
  { day: "Fri", label: "Full Body", done: false, items: ["Burpees 3×8", "Mountain climbers 3×15", "Plank 3×30s", "Cool-down stretch"] },
  { day: "Sat", label: "Active Recovery", done: false, items: ["Yoga 20 min", "Leisure walk"] },
  { day: "Sun", label: "Rest", done: false, items: ["Complete rest", "Hydrate & meal prep"] },
];

function Plan() {
  const [open, setOpen] = useState(null);
  let doneCount = weekPlan.filter(d => d.done).length;

  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F5F5F5", padding: 14 }}>
      <div style={{ fontWeight: 700, fontSize: 20, color: "#1A1A1A", marginBottom: 2 }}>My Plan</div>
      <div style={{ fontSize: 12, color: "#888", marginBottom: 14 }}>Week 2 · Beginner Program</div>

      <div style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", marginBottom: 14, border: "1px solid #EDEDED" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: "#1A1A1A" }}>Weekly Progress</span>
          <span style={{ fontSize: 13, fontWeight: 700, color: O }}>{doneCount}/7</span>
        </div>
        <div style={{ height: 8, background: "#F0F0F0", borderRadius: 4, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${(doneCount / 7) * 100}%`, background: O, borderRadius: 4, transition: "width .3s" }} />
        </div>
      </div>

      {weekPlan.map((d, i) => (
        <div key={i} onClick={() => setOpen(open === i ? null : i)} style={{
          background: "#fff", borderRadius: 14, padding: "12px 14px",
          marginBottom: 8, cursor: "pointer",
          border: d.today ? `2px solid ${O}` : "1px solid #EDEDED",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10, fontWeight: 700, fontSize: 13,
              background: d.done ? O : d.today ? `${O}12` : "#F5F5F5",
              color: d.done ? "#fff" : d.today ? O : "#888",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>{d.done ? "✓" : d.day}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A" }}>{d.label}</div>
              <div style={{ fontSize: 11, color: "#999", marginTop: 1 }}>
                {d.items.length} {d.items.length === 1 ? "activity" : "activities"}
                {d.today && <span style={{ color: O, fontWeight: 600, marginLeft: 6 }}>TODAY</span>}
              </div>
            </div>
            <span style={{
              fontSize: 16, color: "#ccc", transition: "transform .15s",
              transform: open === i ? "rotate(90deg)" : "none", display: "inline-block",
            }}>›</span>
          </div>
          {open === i && (
            <div style={{ marginTop: 12, paddingTop: 10, borderTop: "1px solid #F0F0F0" }}>
              {d.items.map((ex, j) => (
                <div key={j} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0", fontSize: 13, color: "#444" }}>
                  <div style={{ width: 6, height: 6, borderRadius: 3, background: d.done ? O : "#ddd", flexShrink: 0 }} />
                  {ex}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

/* ========== PROFILE ========== */

function Profile() {
  const stats = [
    { l: "Workouts", v: "12" }, { l: "This Week", v: "3" },
    { l: "Streak", v: "5 days" }, { l: "Since", v: "Mar '26" },
  ];
  const badges = [
    { icon: "🔥", title: "First Week", desc: "Completed 7 days of activity" },
    { icon: "🚶", title: "Walking Warrior", desc: "Walked 10 km total" },
    { icon: "💬", title: "Social Butterfly", desc: "Sent 50 group messages" },
  ];
  const menu = ["Edit Profile", "Notifications", "Connected Devices", "Privacy", "Help & Support"];

  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F5F5F5" }}>
      <div style={{ background: "#fff", padding: "24px 14px 20px", textAlign: "center" }}>
        <div style={{
          width: 72, height: 72, borderRadius: 36, background: "#F0F0F0",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 34, margin: "0 auto 10px", border: `3px solid ${O}`,
        }}>👤</div>
        <div style={{ fontWeight: 700, fontSize: 18, color: "#1A1A1A" }}>You</div>
        <div style={{ fontSize: 13, color: "#888", marginTop: 2 }}>Beginner · The Coach Group</div>
        <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 14 }}>
          <button style={{ background: O, color: "#fff", border: "none", borderRadius: 20, padding: "8px 24px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Edit Profile</button>
          <button style={{ background: "#F0F0F0", color: "#333", border: "none", borderRadius: 20, padding: "8px 24px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Share</button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, padding: 14 }}>
        {stats.map((s, i) => (
          <div key={i} style={{ background: "#fff", borderRadius: 14, padding: 14, border: "1px solid #EDEDED", textAlign: "center" }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: "#1A1A1A" }}>{s.v}</div>
            <div style={{ fontSize: 10, color: "#999", marginTop: 2, textTransform: "uppercase", letterSpacing: 0.4 }}>{s.l}</div>
          </div>
        ))}
      </div>

      <div style={{ padding: "0 14px 8px" }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: "#888", textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 10 }}>Achievements</div>
        {badges.map((a, i) => (
          <div key={i} style={{
            background: "#fff", borderRadius: 14, padding: "12px 14px",
            marginBottom: 8, border: "1px solid #EDEDED",
            display: "flex", alignItems: "center", gap: 12,
          }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, fontSize: 20, background: `${O}0D`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{a.icon}</div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A" }}>{a.title}</div>
              <div style={{ fontSize: 12, color: "#999", marginTop: 1 }}>{a.desc}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ padding: "0 14px 20px" }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: "#888", textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 10 }}>Settings</div>
        <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #EDEDED", overflow: "hidden" }}>
          {menu.map((s, i) => (
            <div key={i} style={{
              padding: "14px", fontSize: 14, color: "#1A1A1A",
              borderBottom: i < menu.length - 1 ? "1px solid #F5F5F5" : "none",
              display: "flex", justifyContent: "space-between", alignItems: "center",
              cursor: "pointer",
            }}>{s}<span style={{ color: "#ccc", fontSize: 14 }}>›</span></div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ========== SESSIONS DATA ========== */

// Each "session" is a real-world group workout that members plan together —
// Hyrox sims, group runs, CrossFit WODs, tennis matches. Each has attendees,
// a suggested workout plan, and its own little chat thread so attendees can
// coordinate (carpool, gear, timing). New sessions are created via the
// AI Session Organizer below, which converts natural language into a draft.

const sessionTypes = {
  hyrox:    { label: "Hyrox",    icon: "🏟️", color: "#1976D2" },
  run:      { label: "Run",      icon: "🏃", color: "#34A853" },
  crossfit: { label: "CrossFit", icon: "💪", color: "#8B5CF6" },
  tennis:   { label: "Tennis",   icon: "🎾", color: "#E67E22" },
};

const seedSessions = [
  {
    id: "s1",
    type: "hyrox",
    title: "Weekend Hyrox Simulation",
    description: "Full Hyrox run-through — 8 stations + 1km run repeats.",
    organizer: "mike",
    date: "2026-04-25",
    time: "08:00",
    durationMin: 90,
    location: "Griffith Park — East Lot",
    capacity: 8,
    attendees: ["mike", "sarah", "user"],
    workoutPlan: [
      "Warm-up: 1km easy run + dynamic stretch",
      "Station 1: SkiErg 1000m",
      "Station 2: Sled Push 50m",
      "Station 3: Sled Pull 50m",
      "Station 4: Burpee Broad Jump 80m",
      "Station 5: Rowing 1000m",
      "Station 6: Farmers Carry 200m",
      "Station 7: Sandbag Lunges 100m",
      "Station 8: Wall Balls 100 reps",
    ],
    chatThread: [
      { id: 1, from: "mike",  body: "Bring chalk and lifting straps 💪", t: "Yesterday" },
      { id: 2, from: "sarah", body: "Carpooling from Silver Lake — anyone in?", t: "Yesterday" },
    ],
  },
  {
    id: "s2",
    type: "run",
    title: "Sunrise 5K Along The River",
    description: "Easy-pace group run — no one left behind.",
    organizer: "user",
    date: "2026-04-23",
    time: "06:30",
    durationMin: 45,
    location: "LA River Trail — Fletcher Dr Access",
    capacity: 12,
    attendees: ["user", "jenny"],
    workoutPlan: [
      "5 min brisk-walk warm-up",
      "5K continuous at conversational pace",
      "5 min cool-down stretch",
    ],
    chatThread: [
      { id: 1, from: "jenny", body: "First outdoor run in a while — excited! 🌅", t: "2h ago" },
    ],
  },
  {
    id: "s3",
    type: "crossfit",
    title: "Friday Night Open WOD",
    description: "Tackle the latest Open workout — scaled options available.",
    organizer: "sarah",
    date: "2026-04-24",
    time: "18:00",
    durationMin: 75,
    location: "CrossFit Zone DTLA",
    capacity: 10,
    attendees: ["sarah", "mike"],
    workoutPlan: [
      "Warm-up: 3 rounds — row 200m / 10 air squats",
      "Strength: 5×3 Deadlift @ 75%",
      "WOD: 15 min AMRAP — 10 DB snatch / 12 burpees / 15 wall balls",
      "Cool-down: 5 min mobility",
    ],
    chatThread: [],
  },
  {
    id: "s4",
    type: "tennis",
    title: "Sunday Doubles Round Robin",
    description: "Mixed-level doubles — rotate partners every set.",
    organizer: "jenny",
    date: "2026-04-26",
    time: "10:00",
    durationMin: 120,
    location: "West LA Tennis Club — Court 3",
    capacity: 8,
    attendees: ["jenny", "user"],
    workoutPlan: [
      "Warm-up rally: 15 min",
      "Round 1: 30 min doubles",
      "Round 2: 30 min doubles — new partners",
      "Round 3: 30 min championship",
    ],
    chatThread: [
      { id: 1, from: "jenny", body: "Bringing extra balls 🎾 — need a racquet?", t: "Mon" },
    ],
  },
];

function fmtSessionDate(dateStr) {
  if (!dateStr) return "TBD";
  const d = new Date(dateStr + "T00:00:00");
  if (isNaN(d)) return dateStr;
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

function fmtSessionTime(timeStr) {
  if (!timeStr) return "";
  const [h, m] = timeStr.split(":").map(Number);
  if (isNaN(h) || isNaN(m)) return timeStr;
  const suffix = h >= 12 ? "PM" : "AM";
  return `${h % 12 || 12}:${m < 10 ? "0" + m : m} ${suffix}`;
}

/* ========== SESSIONS LIST ========== */

function Sessions({ sessions, openDetail, openOrganizer, currentUserId }) {
  const [filter, setFilter] = useState("all");
  const types = ["all", ...Object.keys(sessionTypes)];
  const filtered = filter === "all" ? sessions : sessions.filter(s => s.type === filter);
  const sorted = [...filtered].sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));

  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F5F5F5" }}>
      {/* AI Organize call-to-action */}
      <div style={{ padding: 14, background: "#fff", borderBottom: "1px solid #EDEDED" }}>
        <button onClick={openOrganizer} style={{
          width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          background: `linear-gradient(135deg, ${O}, #FF7A3C)`,
          color: "#fff", border: "none", borderRadius: 14, padding: "14px 18px",
          fontSize: 14, fontWeight: 600, cursor: "pointer",
          boxShadow: "0 4px 14px rgba(252,76,2,0.28)",
        }}>
          <span style={{ fontSize: 16 }}>✨</span>
          Plan a session with Coach AI
        </button>
        <div style={{ fontSize: 11, color: "#999", marginTop: 8, textAlign: "center" }}>
          Hyrox · Running · CrossFit · Tennis — just describe what you want
        </div>
      </div>

      {/* Type filter */}
      <div style={{ display: "flex", gap: 6, padding: "12px 14px", overflowX: "auto", background: "#fff", borderBottom: "1px solid #EDEDED" }}>
        {types.map(t => {
          const active = filter === t;
          const meta = sessionTypes[t];
          return (
            <button key={t} onClick={() => setFilter(t)} style={{
              flexShrink: 0, padding: "6px 12px", borderRadius: 16,
              background: active ? O : "#F3F3F3",
              color: active ? "#fff" : "#555",
              border: "none", cursor: "pointer",
              fontSize: 12, fontWeight: 600,
              display: "inline-flex", alignItems: "center", gap: 5,
              transition: "all .15s",
            }}>
              {meta ? <>{meta.icon} {meta.label}</> : "All"}
            </button>
          );
        })}
      </div>

      {/* Session cards */}
      <div style={{ padding: 12 }}>
        {sorted.length === 0 && (
          <div style={{ textAlign: "center", padding: 40, color: "#999", fontSize: 13 }}>
            No sessions yet — tap above to plan one ✨
          </div>
        )}
        {sorted.map(s => (
          <SessionCard key={s.id} s={s} onClick={() => openDetail(s.id)} currentUserId={currentUserId} />
        ))}
      </div>
    </div>
  );
}

function SessionCard({ s, onClick, currentUserId }) {
  const meta = sessionTypes[s.type] || { label: s.type, icon: "💬", color: "#555" };
  const joined = s.attendees.includes(currentUserId);
  const full = s.attendees.length >= s.capacity;
  return (
    <div onClick={onClick} style={{
      background: "#fff", borderRadius: 14, padding: 14, marginBottom: 10,
      border: "1px solid #EDEDED", cursor: "pointer",
    }}>
      <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 10 }}>
        <div style={{
          width: 38, height: 38, borderRadius: 10, fontSize: 18,
          background: `${meta.color}15`, color: meta.color,
          display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
        }}>{meta.icon}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A1A", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.title}</div>
          <div style={{ fontSize: 11, color: "#888", marginTop: 2 }}>
            {fmtSessionDate(s.date)} · {fmtSessionTime(s.time)} · {s.durationMin} min
          </div>
        </div>
        <span style={{
          fontSize: 10, fontWeight: 700, color: meta.color,
          background: `${meta.color}15`, padding: "4px 8px", borderRadius: 10,
          letterSpacing: 0.4,
        }}>{meta.label.toUpperCase()}</span>
      </div>

      <div style={{ fontSize: 12, color: "#666", marginBottom: 10, lineHeight: 1.4 }}>
        📍 {s.location}
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid #F5F5F5", paddingTop: 10 }}>
        <div style={{ display: "flex", alignItems: "center" }}>
          {s.attendees.slice(0, 4).map((a, i) => (
            <div key={a} style={{ marginLeft: i === 0 ? 0 : -8, border: "2px solid #fff", borderRadius: "50%", zIndex: 10 - i }}>
              <Avatar id={a} size={24} />
            </div>
          ))}
          <span style={{ fontSize: 11, color: "#888", marginLeft: 8 }}>
            {s.attendees.length}/{s.capacity}
          </span>
        </div>
        <span style={{
          fontSize: 11, fontWeight: 600,
          color: joined ? "#34A853" : full ? "#aaa" : O,
        }}>
          {joined ? "✓ Joined" : full ? "Full" : "Tap to join →"}
        </span>
      </div>
    </div>
  );
}

/* ========== SESSION DETAIL (attendees + per-session chat) ========== */

function SessionDetail({ session, setSessions, onBack, currentUserId }) {
  const [msg, setMsg] = useState("");
  const chatEnd = useRef(null);
  const uid = useRef(1000);
  const meta = sessionTypes[session.type] || { label: session.type, icon: "💬", color: "#555" };
  const joined = session.attendees.includes(currentUserId);
  const full = !joined && session.attendees.length >= session.capacity;

  useEffect(() => {
    chatEnd.current?.scrollIntoView({ behavior: "smooth" });
  }, [session.chatThread]);

  function toggleJoin() {
    setSessions(prev => prev.map(s => {
      if (s.id !== session.id) return s;
      const isIn = s.attendees.includes(currentUserId);
      if (isIn) return { ...s, attendees: s.attendees.filter(a => a !== currentUserId) };
      if (s.attendees.length >= s.capacity) return s;
      return { ...s, attendees: [...s.attendees, currentUserId] };
    }));
  }

  function sendChat() {
    const t = msg.trim();
    if (!t) return;
    setMsg("");
    setSessions(prev => prev.map(s => {
      if (s.id !== session.id) return s;
      return {
        ...s,
        chatThread: [...s.chatThread, { id: uid.current++, from: currentUserId, body: t, t: timeNow() }],
      };
    }));
  }

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", minHeight: 0, background: "#F5F5F5" }}>
      {/* Header with back */}
      <div style={{
        height: 56, padding: "0 8px", display: "flex", alignItems: "center", gap: 4,
        background: "#fff", borderBottom: "1px solid #EDEDED", flexShrink: 0,
      }}>
        <button onClick={onBack} style={{
          background: "none", border: "none", fontSize: 24, cursor: "pointer",
          color: "#333", width: 40, height: 40, lineHeight: 1,
        }}>‹</button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: "#1A1A1A", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{session.title}</div>
          <div style={{ fontSize: 11, color: "#888" }}>{meta.label} · hosted by {who(session.organizer).name}</div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto" }}>
        {/* Colored banner */}
        <div style={{
          background: `linear-gradient(135deg, ${meta.color}, ${meta.color}BB)`,
          padding: "24px 16px", color: "#fff",
        }}>
          <div style={{ fontSize: 34, marginBottom: 6 }}>{meta.icon}</div>
          <div style={{ fontSize: 18, fontWeight: 700 }}>{fmtSessionDate(session.date)}</div>
          <div style={{ fontSize: 13, opacity: 0.92, marginTop: 3 }}>
            {fmtSessionTime(session.time)} · {session.durationMin} min
          </div>
          <div style={{ fontSize: 13, opacity: 0.92, marginTop: 2 }}>📍 {session.location}</div>
        </div>

        {session.description && (
          <div style={{ background: "#fff", padding: 16, borderBottom: "1px solid #EDEDED" }}>
            <div style={{ fontSize: 13, color: "#444", lineHeight: 1.5 }}>{session.description}</div>
          </div>
        )}

        {/* Attendees + RSVP */}
        <div style={{ background: "#fff", padding: 16, borderBottom: "1px solid #EDEDED" }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "#888", textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 10 }}>
            Attendees · {session.attendees.length}/{session.capacity}
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }}>
            {session.attendees.map(id => (
              <div key={id} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, width: 52 }}>
                <Avatar id={id} size={40} />
                <span style={{
                  fontSize: 10, color: "#666", textAlign: "center",
                  overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 52,
                }}>
                  {who(id).name.split(" ")[0]}{id === session.organizer && " ★"}
                </span>
              </div>
            ))}
          </div>
          <button onClick={toggleJoin} disabled={full} style={{
            width: "100%",
            background: joined ? "#F5F5F5" : full ? "#E8E8E8" : O,
            color: joined ? "#333" : full ? "#aaa" : "#fff",
            border: joined ? "1px solid #E0E0E0" : "none",
            borderRadius: 12, padding: 12, fontSize: 14, fontWeight: 600,
            cursor: full ? "default" : "pointer",
          }}>
            {joined ? "Leave session" : full ? "Session full" : "Join session"}
          </button>
        </div>

        {/* Workout plan */}
        {session.workoutPlan && session.workoutPlan.length > 0 && (
          <div style={{ background: "#fff", padding: 16, borderBottom: "1px solid #EDEDED" }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#888", textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 10 }}>
              Workout Plan
            </div>
            {session.workoutPlan.map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "6px 0", fontSize: 13, color: "#333", lineHeight: 1.45 }}>
                <div style={{
                  width: 20, height: 20, borderRadius: 10, fontSize: 11, fontWeight: 700,
                  background: `${meta.color}15`, color: meta.color,
                  display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 1,
                }}>{i + 1}</div>
                <div style={{ flex: 1 }}>{item}</div>
              </div>
            ))}
          </div>
        )}

        {/* Session chat */}
        <div style={{ background: "#fff", padding: 16, borderBottom: "1px solid #EDEDED" }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "#888", textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 10 }}>
            Session Chat
          </div>
          {session.chatThread.length === 0 && (
            <div style={{ fontSize: 12, color: "#aaa", padding: "16px 0", textAlign: "center" }}>
              Be the first to say hi 👋
            </div>
          )}
          {session.chatThread.map(m => {
            const p = who(m.from);
            const mine = m.from === currentUserId;
            return (
              <div key={m.id} style={{
                display: "flex", flexDirection: mine ? "row-reverse" : "row",
                gap: 8, marginBottom: 8, alignItems: "flex-start",
              }}>
                <Avatar id={m.from} size={28} />
                <div style={{ maxWidth: "72%" }}>
                  {!mine && <div style={{ fontSize: 11, fontWeight: 600, color: "#555", marginBottom: 2 }}>{p.name}</div>}
                  <div style={{
                    padding: "8px 12px", borderRadius: 14,
                    background: mine ? O : "#F5F5F5",
                    color: mine ? "#fff" : "#1A1A1A",
                    fontSize: 13, lineHeight: 1.4,
                  }}>{m.body}</div>
                  <div style={{ fontSize: 10, color: "#B0B0B0", marginTop: 2, textAlign: mine ? "right" : "left" }}>{m.t}</div>
                </div>
              </div>
            );
          })}
          <div ref={chatEnd} />
        </div>
      </div>

      {/* Chat composer */}
      <div style={{
        padding: "8px 10px 10px", display: "flex", gap: 6, alignItems: "center",
        borderTop: "1px solid #EDEDED", background: "#fff", flexShrink: 0,
      }}>
        <input
          value={msg}
          onChange={e => setMsg(e.target.value)}
          onKeyDown={e => e.key === "Enter" && sendChat()}
          placeholder={joined ? "Message attendees..." : "Join to chat with attendees"}
          disabled={!joined}
          style={{
            flex: 1, background: "#F5F5F5", border: "none", borderRadius: 20,
            padding: "9px 14px", fontSize: 14, color: "#1A1A1A", outline: "none",
            minWidth: 0, opacity: joined ? 1 : 0.55,
          }}
        />
        <button onClick={sendChat} disabled={!joined || !msg.trim()} style={{
          background: joined && msg.trim() ? O : "#E0E0E0",
          border: "none", borderRadius: 20, width: 34, height: 34,
          cursor: joined && msg.trim() ? "pointer" : "default",
          fontSize: 14, color: "#fff",
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0, transition: "background .15s",
        }}>↑</button>
      </div>
    </div>
  );
}

/* ========== AI SESSION ORGANIZER ==========
   Natural-language → structured session draft, powered by GPT-4o JSON mode.
   Shows a live-updating draft card while you chat. Confirm to add it to Sessions. */

function SessionOrganizer({ onClose, onCreate, currentUserId }) {
  const today = new Date().toISOString().slice(0, 10);
  const [chat, setChat] = useState([
    {
      id: 1, from: "ai",
      body: "Let's plan your session. Tell me the type (Hyrox, Run, CrossFit, or Tennis), when & where, and any details you want — I'll fill in the rest 💪",
    },
  ]);
  const [draft, setDraft] = useState({
    type: null, title: "", description: "",
    date: null, time: null, durationMin: null,
    location: "", capacity: null, workoutPlan: [],
  });
  const [val, setVal] = useState("");
  const [typing, setTyping] = useState(false);
  const [history, setHistory] = useState([]);
  const endRef = useRef(null);
  const uid = useRef(100);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [chat, typing]);

  const systemPrompt = `You are Coach Fit, an AI session organizer for The Coach fitness app.
Your job is to convert natural-language descriptions into structured group workout sessions.

Today's date is ${today}.

Respond ONLY with valid JSON in this exact shape (no markdown, no extra text):
{
  "reply": "short friendly chat message (1-2 sentences, 1 relevant emoji)",
  "draft": {
    "type": "hyrox" | "run" | "crossfit" | "tennis" | null,
    "title": "catchy session title or empty string",
    "description": "1-sentence description or empty string",
    "date": "YYYY-MM-DD or null",
    "time": "HH:MM 24-hour or null",
    "durationMin": number of minutes (30-180) or null,
    "location": "location string or empty string",
    "capacity": number (2-20) or null,
    "workoutPlan": array of short step strings (<=60 chars each; can be empty)
  }
}

Rules:
- Resolve relative dates ("next Saturday", "tomorrow", "this weekend") based on today.
- Only update fields the user indicates; preserve previously-filled fields.
- Suggest a sensible workoutPlan for the chosen session type once the user asks or once type is known and no plan exists yet.
- If the user's message is off-topic, gently steer them back to planning.
- The reply should either ask a targeted follow-up for the next missing field (type → date → time → location → capacity → plan), or confirm when everything is set.`;

  async function sendMsg() {
    const t = val.trim();
    if (!t || typing) return;
    setVal("");
    setChat(p => [...p, { id: uid.current++, from: "user", body: t }]);
    setTyping(true);

    const updatedHistory = [
      ...history,
      { role: "user", content: `${t}\n\n[current draft snapshot: ${JSON.stringify(draft)}]` },
    ];

    try {
      const res = await fetch(`${BASE_URL}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${API_KEY}`,
        },
        body: JSON.stringify({
          model: MODEL,
          max_tokens: 500,
          response_format: { type: "json_object" },
          messages: [
            { role: "system", content: systemPrompt },
            ...updatedHistory,
          ],
        }),
      });
      const data = await res.json();
      const content = data.choices?.[0]?.message?.content || "{}";
      let parsed;
      try { parsed = JSON.parse(content); }
      catch { parsed = { reply: "I got confused — mind rephrasing? 🤔", draft: null }; }

      if (parsed.draft && typeof parsed.draft === "object") {
        setDraft(prev => {
          const next = { ...prev };
          for (const [k, v] of Object.entries(parsed.draft)) {
            if (v === null || v === undefined) continue;
            if (typeof v === "string" && v.trim() === "" && prev[k]) continue;
            if (Array.isArray(v) && v.length === 0 && Array.isArray(prev[k]) && prev[k].length > 0) continue;
            next[k] = v;
          }
          return next;
        });
      }

      setHistory([...updatedHistory, { role: "assistant", content }]);
      setTyping(false);
      setChat(p => [...p, { id: uid.current++, from: "ai", body: parsed.reply || "Got it!" }]);
    } catch (err) {
      setTyping(false);
      setChat(p => [...p, { id: uid.current++, from: "ai", body: "Connection error — let's try again 🔌" }]);
    }
  }

  const canCreate = !!(draft.type && draft.date && draft.time && draft.location);

  function handleCreate() {
    if (!canCreate) return;
    const meta = sessionTypes[draft.type];
    onCreate({
      id: "s" + Date.now(),
      type: draft.type,
      title: draft.title?.trim() || `${meta.label} Session`,
      description: draft.description || "",
      organizer: currentUserId,
      date: draft.date,
      time: draft.time,
      durationMin: draft.durationMin || 60,
      location: draft.location,
      capacity: draft.capacity || 8,
      attendees: [currentUserId],
      workoutPlan: Array.isArray(draft.workoutPlan) ? draft.workoutPlan : [],
      chatThread: [],
    });
  }

  return (
    <div style={{
      position: "absolute", inset: 0, zIndex: 100,
      background: "#fff", display: "flex", flexDirection: "column",
    }}>
      {/* Header */}
      <div style={{
        height: 56, padding: "0 8px", display: "flex", alignItems: "center", gap: 6,
        borderBottom: "1px solid #EDEDED", flexShrink: 0,
      }}>
        <button onClick={onClose} style={{
          background: "none", border: "none", fontSize: 18, cursor: "pointer",
          color: "#666", width: 40, height: 40,
        }}>✕</button>
        <div style={{
          width: 32, height: 32, borderRadius: 16, background: O,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 15, color: "#fff", flexShrink: 0,
        }}>🏋️</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: "#1A1A1A" }}>Plan with Coach AI</div>
          <div style={{ fontSize: 11, color: "#888" }}>Describe your session — AI fills in the details</div>
        </div>
      </div>

      {/* Live draft preview */}
      <DraftPreview draft={draft} />

      {/* Chat */}
      <div style={{ flex: 1, overflowY: "auto", background: "#F5F5F5", padding: "10px 12px", minHeight: 0 }}>
        {chat.map(m => {
          const isAI = m.from === "ai";
          return (
            <div key={m.id} className="msg-enter" style={{
              display: "flex", flexDirection: isAI ? "row" : "row-reverse",
              gap: 8, marginBottom: 8, alignItems: "flex-start",
            }}>
              {isAI && (
                <div style={{
                  width: 28, height: 28, borderRadius: 14, background: O,
                  color: "#fff", display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 14, flexShrink: 0,
                }}>🏋️</div>
              )}
              <div style={{
                maxWidth: "82%",
                padding: "10px 14px", borderRadius: 16,
                borderTopLeftRadius: isAI ? 4 : 16,
                borderTopRightRadius: isAI ? 16 : 4,
                background: isAI ? "#fff" : O,
                color: isAI ? "#1A1A1A" : "#fff",
                fontSize: 13.5, lineHeight: 1.5,
                border: isAI ? "1px solid #ECECEC" : "none",
              }}>{m.body}</div>
            </div>
          );
        })}
        {typing && (
          <div className="msg-enter" style={{ display: "flex", alignItems: "center", gap: 8, paddingLeft: 36, paddingTop: 2 }}>
            <div style={{ display: "flex", gap: 4 }}>
              {[0, 1, 2].map(i => (
                <div key={i} style={{
                  width: 6, height: 6, borderRadius: 3, background: O, opacity: 0.5,
                  animation: `dotPulse 1.4s ease-in-out ${i * 0.16}s infinite both`,
                }} />
              ))}
            </div>
            <span style={{ fontSize: 12, color: "#999" }}>Coach AI is thinking</span>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Create button */}
      <div style={{ padding: "8px 10px 0", background: "#fff", borderTop: "1px solid #EDEDED", flexShrink: 0 }}>
        <button onClick={handleCreate} disabled={!canCreate} style={{
          width: "100%", padding: 12, borderRadius: 12,
          background: canCreate ? O : "#E8E8E8",
          color: canCreate ? "#fff" : "#aaa",
          border: "none", fontSize: 14, fontWeight: 600,
          cursor: canCreate ? "pointer" : "default",
        }}>
          {canCreate ? "✓ Create session" : "Need type, date, time & location"}
        </button>
      </div>

      {/* Input */}
      <div style={{ padding: "8px 10px 10px", display: "flex", gap: 6, background: "#fff", flexShrink: 0 }}>
        <input
          value={val}
          onChange={e => setVal(e.target.value)}
          onKeyDown={e => e.key === "Enter" && sendMsg()}
          placeholder="e.g. Hyrox sim Saturday 8am at the park"
          disabled={typing}
          style={{
            flex: 1, background: "#F5F5F5", border: "none", borderRadius: 20,
            padding: "10px 14px", fontSize: 14, color: "#1A1A1A", outline: "none",
          }}
        />
        <button onClick={sendMsg} disabled={!val.trim() || typing} style={{
          background: val.trim() && !typing ? O : "#E0E0E0",
          border: "none", borderRadius: 20, width: 38, height: 38,
          cursor: val.trim() && !typing ? "pointer" : "default",
          fontSize: 14, color: "#fff",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>↑</button>
      </div>
    </div>
  );
}

function DraftPreview({ draft }) {
  const meta = draft.type ? sessionTypes[draft.type] : null;
  const rows = [
    { icon: "🏷️", label: "Type",     value: meta ? `${meta.icon} ${meta.label}` : null },
    { icon: "📅", label: "When",     value: draft.date ? `${fmtSessionDate(draft.date)} · ${fmtSessionTime(draft.time) || "time?"}` : null },
    { icon: "📍", label: "Where",    value: draft.location || null },
    { icon: "⏱️", label: "Duration", value: draft.durationMin ? `${draft.durationMin} min` : null },
    { icon: "👥", label: "Capacity", value: draft.capacity ? `up to ${draft.capacity}` : null },
  ];
  const color = meta?.color || O;
  return (
    <div style={{
      background: `linear-gradient(135deg, ${color}14, ${color}05)`,
      padding: "12px 14px",
      borderBottom: "1px solid #EDEDED",
      flexShrink: 0,
    }}>
      <div style={{ fontSize: 10, fontWeight: 700, color, textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 4 }}>
        Draft Session
      </div>
      <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A1A", marginBottom: 8 }}>
        {draft.title || "Untitled session"}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
        {rows.map((r, i) => (
          <div key={i} style={{ fontSize: 11, color: r.value ? "#444" : "#bbb" }}>
            <span style={{ marginRight: 4 }}>{r.icon}</span>
            {r.value || `${r.label}?`}
          </div>
        ))}
      </div>
      {Array.isArray(draft.workoutPlan) && draft.workoutPlan.length > 0 && (
        <div style={{ marginTop: 8, fontSize: 11, color: "#666", lineHeight: 1.5 }}>
          <span style={{ fontWeight: 600, color: "#444" }}>Plan:</span>{" "}
          {draft.workoutPlan.slice(0, 3).join(" · ")}
          {draft.workoutPlan.length > 3 && ` +${draft.workoutPlan.length - 3} more`}
        </div>
      )}
    </div>
  );
}

/* ========== CHAT ========== */

// NPC messages to simulate other group members
const npcBank = {
  sarah: [
    "Just finished my first full week of walks! Bumped it to 20 min by day 5 😊",
    "Coach, is it normal to feel sore after stretching?",
    "Mike your progress is inspiring! How long before you saw changes?",
    "Anyone else doing the morning routine Coach shared?",
    "Is it better to work out morning or evening?",
  ],
  mike: [
    "New PR — 5K in under 30 minutes! 🎉",
    "Sarah keep going! First two weeks are hardest, then it clicks",
    "Coach, should I stretch before or after runs?",
    "This group keeps me accountable — love it",
    "Tried the plank routine. Only held 15 seconds but it's a start 😅",
  ],
  jenny: [
    "Hey everyone! Trying to get back in shape postpartum 👋",
    "Coach, any exercises to avoid postpartum?",
    "The pool is my happy place — any beginner swim workouts?",
    "Sarah and Mike you guys are goals!",
  ],
};

// Seed messages shown on first load
const chatSeed = [
  { id: 1, from: "coach", body: "Welcome to The Coach! 🎉 Ask me anything about workouts, nutrition, or getting started — share photos for form checks and equipment advice!", t: "9:00 AM", embed: true },
  { id: 2, from: "sarah", body: "Hey everyone! Just joined 👋 Never worked out before — where do I start?", t: "9:02 AM" },
  { id: 3, from: "coach", body: "Welcome Sarah! Start with 15 minutes of walking daily. Once it's a habit, we'll build from there 🌟", t: "9:02 AM",
    aiImg: { url: "https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=400&h=260&fit=crop", caption: "Walking exercise for beginners" }, embed: true },
  { id: 4, from: "mike", body: "Welcome Sarah! This group changed everything for me. Don't be shy to ask anything!", t: "9:03 AM" },
  { id: 5, from: "sarah", body: "Thanks everyone! Starting tomorrow morning 💪", t: "9:04 AM" },
  { id: 6, from: "coach", body: "That's the spirit! Consistency over intensity — even 10 minutes counts on tired days. We're all cheering you on 🧡", t: "9:05 AM", embed: true },
];

function Chat({ chat, setChat, uid }) {
  const [val, setVal] = useState("");
  const [typing, setTyping] = useState(null);
  const [panel, setPanel] = useState(null);
  const [hover, setHover] = useState(false);

  // Conversation history for multi-turn AI context
  const [history, setHistory] = useState([]);

  const end = useRef(null);
  const fRef = useRef(null);

  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [chat, typing]);

  // Call the real AI API — supports optional image (base64) for photo analysis
  const reply = useCallback(async (userText, imageBase64 = null) => {
    setTyping("Coach Fit");

    // Build content: text only, or text + image for form checks
    const userContent = imageBase64
      ? [
          { type: "image_url", image_url: { url: imageBase64 } },
          { type: "text", text: userText || "Please check my form in this photo." },
        ]
      : userText;

    const updatedHistory = [
      ...history,
      { role: "user", content: userContent },
    ];

    try {
      const res = await fetch(`${BASE_URL}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${API_KEY}`,
        },
        body: JSON.stringify({
          model: MODEL,
          max_tokens: 300,
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            ...updatedHistory,
          ],
        }),
      });

      const data = await res.json();
      const aiText = data.choices?.[0]?.message?.content || "Sorry, I couldn't process that. Please try again.";

      // Append assistant reply to history so the next turn has full context
      setHistory([...updatedHistory, { role: "assistant", content: aiText }]);

      setTyping(null);
      setChat(p => [...p, {
        id: uid.current++,
        from: "coach",
        body: aiText,
        t: timeNow(),
        embed: true,
      }]);
    } catch (err) {
      setTyping(null);
      setChat(p => [...p, {
        id: uid.current++,
        from: "coach",
        body: "Connection error — please check your API key or network. 🔌",
        t: timeNow(),
      }]);
    }
  }, [history, uid, setChat]);

  // Send a typed text message
  function send() {
    let t = val.trim();
    if (!t || typing) return;
    setVal("");
    setChat(p => [...p, { id: uid.current++, from: "user", body: t, t: timeNow() }]);
    reply(t);
  }

  // Handle file or image upload — images are sent to AI for visual analysis
  function onFile(file) {
    if (!file || typing) return;
    const reader = new FileReader();
    reader.onload = e => {
      const base64 = e.target.result;
      const isImg = file.type.startsWith("image/");
      setChat(p => [...p, {
        id: uid.current++,
        from: "user",
        t: timeNow(),
        body: isImg ? "" : `📎 ${file.name}`,
        userImg: isImg ? base64 : null,
      }]);
      reply(isImg ? "" : `User shared a file: ${file.name}`, isImg ? base64 : null);
    };
    reader.readAsDataURL(file);
  }

  // Simulate a random NPC group member sending a message (no AI reply triggered)
  function npc() {
    if (typing) return;
    const ks = Object.keys(npcBank);
    const k = ks[Math.floor(Math.random() * ks.length)];
    const ls = npcBank[k];
    setTyping(who(k).name);
    setTimeout(() => {
      setTyping(null);
      setChat(p => [...p, {
        id: uid.current++,
        from: k,
        body: ls[Math.floor(Math.random() * ls.length)],
        t: timeNow(),
      }]);
    }, 500 + Math.random() * 700);
  }

  const onlineN = ppl.filter(p => p.status === "online").length;

  return (
    <div
      onDragOver={e => { e.preventDefault(); setHover(true); }}
      onDragLeave={() => setHover(false)}
      onDrop={e => { e.preventDefault(); setHover(false); onFile(e.dataTransfer.files[0]); }}
      style={{ flex: 1, display: "flex", flexDirection: "column", position: "relative", minHeight: 0 }}
    >
      {/* Drag-and-drop overlay */}
      {hover && (
        <div style={{
          position: "absolute", inset: 0, zIndex: 50,
          background: "rgba(252,76,2,0.07)", display: "flex",
          alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 4,
        }}>
          <span style={{ fontSize: 26 }}>📷</span>
          <span style={{ color: O, fontWeight: 600, fontSize: 14 }}>Drop image or file</span>
        </div>
      )}

      {/* Chat header */}
      <div style={{
        height: 56, padding: "0 14px", display: "flex", alignItems: "center", gap: 10,
        background: "#fff", borderBottom: "1px solid #EDEDED", flexShrink: 0,
      }}>
        <div style={{ position: "relative" }}>
          <div style={{
            width: 36, height: 36, borderRadius: 18, background: O,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 17, color: "#fff",
          }}>🏋️</div>
          <Dot s="online" />
        </div>
        <div style={{ flex: 1, cursor: "pointer" }} onClick={() => setPanel(panel === "info" ? null : "info")}>
          <div style={{ fontWeight: 700, fontSize: 15, color: "#1A1A1A" }}>The Coach</div>
          <div style={{ fontSize: 11, color: "#888", marginTop: 1 }}>{onlineN} online · {ppl.length} members</div>
        </div>
        <button onClick={() => setPanel(panel === "members" ? null : "members")} style={{
          background: "none", border: "none", fontSize: 18, cursor: "pointer",
          color: panel === "members" ? O : "#666", padding: "4px 8px",
        }}>👥</button>
      </div>

      {/* Group info panel */}
      {panel === "info" && (
        <div style={{ background: "#fff", borderBottom: "1px solid #EDEDED", padding: "12px 16px", flexShrink: 0 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "#888", textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 8 }}>About</div>
          <p style={{ fontSize: 13, color: "#444", lineHeight: 1.5, margin: 0 }}>
            AI-powered fitness coaching for all levels. Personalized plans, form checks via photo, nutrition advice, and group motivation. Powered by embeddings.
          </p>
          <div style={{ display: "flex", gap: 6, marginTop: 10, flexWrap: "wrap" }}>
            {["Fitness", "AI Coach", "Nutrition", "Beginners"].map(t => (
              <span key={t} style={{ fontSize: 11, padding: "3px 10px", borderRadius: 12, background: "#F3F3F3", color: "#666", fontWeight: 500 }}>{t}</span>
            ))}
          </div>
        </div>
      )}

      {/* Members panel */}
      {panel === "members" && (
        <div style={{ background: "#fff", borderBottom: "1px solid #EDEDED", padding: "8px 14px", flexShrink: 0 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "#888", textTransform: "uppercase", letterSpacing: 0.6, padding: "4px 2px 8px" }}>Members · {ppl.length}</div>
          {ppl.map(p => (
            <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 2px" }}>
              <Avatar id={p.id} size={32} />
              <div style={{ flex: 1 }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: "#1A1A1A" }}>{p.name}</span>
                <span style={{ fontSize: 10, color: "#999", marginLeft: 6 }}>{p.tag}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Message list */}
      <div style={{ flex: 1, overflowY: "auto", padding: "8px 12px", background: "#F5F5F5", display: "flex", flexDirection: "column", gap: 2, minHeight: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0 6px" }}>
          <div style={{ flex: 1, height: 1, background: "#E0E0E0" }} />
          <span style={{ fontSize: 11, color: "#999", fontWeight: 500 }}>Today</span>
          <div style={{ flex: 1, height: 1, background: "#E0E0E0" }} />
        </div>

        {chat.map(msg => {
          const p = who(msg.from);
          const mine = msg.from === "user";
          const coach = msg.from === "coach";
          return (
            <div key={msg.id} className="msg-enter" style={{
              display: "flex", flexDirection: mine ? "row-reverse" : "row",
              alignItems: "flex-start", gap: 8, maxWidth: "82%",
              alignSelf: mine ? "flex-end" : "flex-start", marginBottom: 3,
            }}>
              {!mine && <div style={{ marginTop: 18 }}><Avatar id={msg.from} size={28} /></div>}
              <div style={{ minWidth: 0 }}>
                {!mine && (
                  <div style={{ fontSize: 11, fontWeight: 600, marginBottom: 2, paddingLeft: 2, color: coach ? O : "#555" }}>
                    {p.name}{coach && <span style={{ fontWeight: 400, color: "#bbb", marginLeft: 4, fontSize: 10 }}>· AI</span>}
                  </div>
                )}
                <div style={{
                  padding: msg.userImg && !msg.body ? "3px" : "10px 14px",
                  borderRadius: 18, borderTopLeftRadius: mine ? 18 : 4, borderTopRightRadius: mine ? 4 : 18,
                  background: mine ? O : "#fff", color: mine ? "#fff" : "#1A1A1A",
                  fontSize: 14, lineHeight: 1.55, border: mine ? "none" : "1px solid #ECECEC",
                  boxShadow: "0 1px 2px rgba(0,0,0,0.03)",
                }}>
                  {msg.userImg && <img src={msg.userImg} alt="" style={{ borderRadius: 15, maxWidth: 210, maxHeight: 170, objectFit: "cover", display: "block" }} />}
                  {msg.body && <div style={msg.userImg ? { marginTop: 6 } : {}}>{msg.body}</div>}
                  {msg.aiImg && (
                    <div style={{ marginTop: 10 }}>
                      <img src={msg.aiImg.url} alt="" style={{ borderRadius: 12, width: "100%", maxWidth: 230, maxHeight: 150, objectFit: "cover", display: "block" }} />
                      <div style={{ fontSize: 11, color: "#888", marginTop: 4 }}>{msg.aiImg.caption}</div>
                    </div>
                  )}
                  {msg.embed && (
                    <div style={{ display: "inline-flex", alignItems: "center", gap: 4, marginTop: 8, background: `${O}0D`, borderRadius: 4, padding: "2px 8px", fontSize: 10, color: O, fontWeight: 500 }}>
                      ⚡ AI response
                    </div>
                  )}
                </div>
                <div style={{ fontSize: 10, color: "#B0B0B0", marginTop: 2, textAlign: mine ? "right" : "left", padding: "0 4px" }}>
                  {msg.t}{mine && " ✓✓"}
                </div>
              </div>
            </div>
          );
        })}

        {/* Typing indicator */}
        {typing && (
          <div className="msg-enter" style={{ display: "flex", alignItems: "center", gap: 8, paddingLeft: 38, paddingTop: 4 }}>
            <div style={{ display: "flex", gap: 4 }}>
              {[0, 1, 2].map(i => (
                <div key={i} style={{ width: 6, height: 6, borderRadius: 3, background: O, opacity: 0.5, animation: `dotPulse 1.4s ease-in-out ${i * 0.16}s infinite both` }} />
              ))}
            </div>
            <span style={{ fontSize: 12, color: "#999" }}>{typing} is typing</span>
          </div>
        )}
        <div ref={end} />
      </div>

      {/* Simulate NPC button */}
      <div style={{ padding: "4px 12px", background: "#F5F5F5", flexShrink: 0 }}>
        <button onClick={npc} disabled={!!typing} style={{
          width: "100%", background: "#fff", border: "1px solid #E8E8E8",
          color: typing ? "#ccc" : "#888", borderRadius: 20, padding: "7px 0",
          cursor: typing ? "default" : "pointer", fontSize: 12, fontWeight: 500,
        }}>💬 Simulate group member message</button>
      </div>

      {/* Message input bar */}
      <div style={{ padding: "8px 10px 10px", display: "flex", gap: 6, alignItems: "center", borderTop: "1px solid #EDEDED", background: "#fff", flexShrink: 0 }}>
        <input
          type="file"
          ref={fRef}
          accept="image/*,.pdf,.doc,.docx,.txt"
          style={{ display: "none" }}
          onChange={e => { onFile(e.target.files[0]); e.target.value = ""; }}
        />
        <button onClick={() => fRef.current?.click()} style={{
          background: "#F5F5F5", border: "none", borderRadius: 20,
          width: 34, height: 34, cursor: "pointer", fontSize: 16,
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "#888", flexShrink: 0,
        }}>+</button>
        <input
          value={val}
          onChange={e => setVal(e.target.value)}
          onKeyDown={e => e.key === "Enter" && send()}
          placeholder="Message the group..."
          style={{ flex: 1, background: "#F5F5F5", border: "none", borderRadius: 20, padding: "9px 14px", fontSize: 14, color: "#1A1A1A", outline: "none", minWidth: 0 }}
        />
        <button onClick={send} disabled={!val.trim() || !!typing} style={{
          background: val.trim() && !typing ? O : "#E0E0E0",
          border: "none", borderRadius: 20, width: 34, height: 34,
          cursor: val.trim() && !typing ? "pointer" : "default",
          fontSize: 14, color: "#fff",
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0, transition: "background .15s",
        }}>↑</button>
      </div>
    </div>
  );
}

/* ========== APP ========== */

const SESSIONS_STORAGE_KEY = "the-coach.sessions.v1";
const CURRENT_USER_ID = "user";

export default function App() {
  const [tab, setTab] = useState("sessions");
  const [chat, setChat] = useState(chatSeed);

  // Sessions persist across reloads so demo state feels real.
  const [sessions, setSessions] = useState(() => {
    try {
      const saved = localStorage.getItem(SESSIONS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return seedSessions;
  });
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [showOrganizer, setShowOrganizer] = useState(false);
  const uid = useRef(7);

  useEffect(() => {
    try { localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(sessions)); } catch {}
  }, [sessions]);

  const activeSession = sessions.find(s => s.id === activeSessionId) || null;

  function handleCreate(session) {
    setSessions(prev => [session, ...prev]);
    setShowOrganizer(false);
    setActiveSessionId(session.id);
    setTab("sessions");
  }

  const subtitle =
    tab === "feed" ? "Activity Feed" :
    tab === "sessions" ? "Group Sessions" :
    tab === "plan" ? "Training Plan" :
    "Your Profile";

  // Hide the global header on chat and when inside a session detail (both render their own header).
  const showHeader = tab !== "chat" && !(tab === "sessions" && activeSession);

  return (
    <div style={{
      width: 390, maxWidth: "100vw", height: "100vh", maxHeight: 844,
      margin: "0 auto", display: "flex", flexDirection: "column",
      background: "#fff", borderRadius: 16, overflow: "hidden",
      position: "relative",
      fontFamily: "-apple-system, 'Helvetica Neue', Helvetica, Arial, sans-serif",
      boxShadow: "0 4px 24px rgba(0,0,0,0.10)",
    }}>
      <style>{`
        @keyframes dotPulse{0%,80%,100%{transform:scale(0)}40%{transform:scale(1)}}
        @keyframes slideUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        .msg-enter{animation:slideUp .2s ease-out}
        input::placeholder{color:#999}
        *::-webkit-scrollbar{width:0;height:0}
      `}</style>

      {showHeader && <Header title="The Coach" subtitle={subtitle} />}

      {tab === "feed" && <Feed />}
      {tab === "chat" && <Chat chat={chat} setChat={setChat} uid={uid} />}
      {tab === "sessions" && !activeSession && (
        <Sessions
          sessions={sessions}
          openDetail={setActiveSessionId}
          openOrganizer={() => setShowOrganizer(true)}
          currentUserId={CURRENT_USER_ID}
        />
      )}
      {tab === "sessions" && activeSession && (
        <SessionDetail
          session={activeSession}
          setSessions={setSessions}
          onBack={() => setActiveSessionId(null)}
          currentUserId={CURRENT_USER_ID}
        />
      )}
      {tab === "plan" && <Plan />}
      {tab === "profile" && <Profile />}

      <TabBar tab={tab} setTab={(t) => { setActiveSessionId(null); setTab(t); }} />

      {showOrganizer && (
        <SessionOrganizer
          onClose={() => setShowOrganizer(false)}
          onCreate={handleCreate}
          currentUserId={CURRENT_USER_ID}
        />
      )}
    </div>
  );
}
